function mostrarMensagem() {
    const mensagem = document.getElementById("mensagem");
    mensagem.innerText = "Você é capaz de conquistar grandes coisas!";
}
